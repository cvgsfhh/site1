from django.shortcuts import render

from product.models import Product


# Create your views here.
def home(request):
    products = Product.objects.filter(status=1)
    result= list(products.values('id' ,'logo','slug'))
    context = {'products':result}
    return render(request, 'home.html', context)